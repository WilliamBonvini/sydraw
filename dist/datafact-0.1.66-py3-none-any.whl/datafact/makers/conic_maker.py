import math
import os
from random import uniform
import numpy as np
import matplotlib.pyplot as plt
import random as rand
import scipy.io

from datafact.makers.circle_maker import CircleMaker
from datafact.makers.ellipse_maker import EllipseMaker
from datafact.makers.line_maker import LineMaker
from datafact.makers.maker import Maker
from datafact.utils.utils import checkExistenceAndCreate, convert_to_np_struct_and_shuffle, convert_to_mat_struct, \
    compute_num_of_inliers_for_each_model, plot_sample, \
    convert_to_np_struct


class ConicMaker(Maker):

    def __init__(self):
        Maker.MODEL = 'conics'
        print("sono nel costruttore di conicmaker")
        self.circle_maker = CircleMaker()
        print("guarda mamma ho creato un circle_maker! {}".format(self.circle_maker))
        self.line_maker = LineMaker()
        print("guarda mamma ho creato un line_maker! {}".format(self.line_maker))
        self.ellipse_maker = EllipseMaker()
        print("guarda mamma ho creato un ellipse_maker! {}".format(self.ellipse_maker))

        super(ConicMaker, self).__init__()


    def generate_random_model(self, n_inliers=None):
        """
        :param n_inliers: number of inlier points for this specific model
        :return:
        """
        print("bravo! sei nell'effettivo generate_random_model()!! grandissimo")
        randNum = np.random.rand(0, 3)
        if randNum == 0:
            print("entered1")
            return self.circle_maker.generate_random_model(n_inliers)
        if randNum == 1:
            print("entered2")
            return self.line_maker.generate_random_model(n_inliers)
        if randNum == 2:
            print("entered3")
            return self.ellipse_maker.generate_random_model(n_inliers)














