import math
import string

import matplotlib.pyplot as plt
from math import pi, cos, sin
from random import random,uniform
import numpy as np
from random import randrange
import random as rand
import numpy as np
import os

import scipy.io

from datafact.coxswain import Coxwain
from datafact.utils import getRanges, checkExistenceAndCreate

coxwain = Coxwain(os.getcwd())






def set_train_dir(path: string):
    coxwain.setTrainDir(path)


def set_test_dir(path: string):
    coxwain.setTestDir(path)


#I could insert this function in the one above, but let's first write it independetly.
#this function creates outliers within a bounding box
# - whose length is 6 times the radius of the circle (mid point is the center of the circle)
# - whose height is 6 times the radius of the circle (mid point is the center of the circle)
def outliers_uniform(h,k,r):
    x = uniform(h-2*r,h+2*r)
    y = uniform(k-2*r,k+2*r)
    return x,y

# creates a circle corrupted by noise with the parameters specified.
def create_noisy_circle(x_center, y_center, radius, n_inliers = None, outliers_perc = None, plot=False):
    xy = [point(y_center, x_center, radius) for _ in range(n_inliers)]
    n_outliers = coxwain.getNumPointsPerSample() - n_inliers
    xy_outliers = [outliers_uniform(x_center, y_center, radius) for _ in range(n_outliers)]

    if plot:
        plt.scatter(*zip(*xy), s=2)
        plt.scatter(*zip(*xy_outliers), s=2)
        plt.grid(color='k', linestyle=':', linewidth=1)
        plt.axes().set_aspect('equal', 'datalim')
        plt.gca().set_aspect('equal', adjustable='box')
        # save plot once in a while
        random_number = randrange(10000)
        if random_number % 20 == 0:
            folder = './'+coxwain.getBaseDir()+'/'+coxwain.getCurDir()+'/'+'imgs'+'/' + 'circles_no_' + str(int(outliers_perc * 100)) + '/' + str(randrange(10000)) + ".png"
            checkExistenceAndCreate(folder)
            plt.savefig(folder)

        # show it
        plt.show()

    return xy, xy_outliers











def convert_to_mat_struct(circle):
    """

    :param circle:
    :return:
    """
    x1p = np.array([elem for elem in circle[0, :]], dtype=np.float32)
    x2p = np.array([elem for elem in circle[1, :]], dtype=np.float32)
    labels = np.array([elem for elem in circle[2, :]], dtype=np.uint8)

    circle_mat = (x1p, x2p, labels)
    return circle_mat





def generate_circle(x_center: float, y_center: float, radius: float, n_inliers: int, outliers_perc: float = None):
    """
    generates a circle
    :param x_center: x of circle
    :param y_center: y of circle
    :param radius:  radius of circle
    :param n_inliers: number of points that are to be inliers
    :param outliers_perc: percentage of outliers
    :return:
    """
    inliers, outliers = create_noisy_circle(x_center, y_center, radius, n_inliers=n_inliers,
                                            outliers_perc=outliers_perc, plot=True)
    inliers = np.array(inliers)
    rows = inliers.shape[0]
    columns = inliers.shape[1]

    n_outliers = coxwain.getNumPointsPerSample() - rows

    # set value of last column to 0 for inliers
    inliers_out = np.zeros((rows, columns + 1))
    inliers_out[:, 0:2] = inliers

    # set value of last column to 1 for outliers
    outliers_out = np.ones((n_outliers, columns + 1))
    outliers_out[:, 0:2] = outliers

    # concatenate arrays and shuffle
    circle = np.concatenate((inliers_out, outliers_out), axis=0)
    np.random.shuffle(circle)
    circle = circle.T
    circle_mat = convert_to_mat_struct(circle)

    return circle_mat







# draws a random point belonging to a circle with center (h,k) and radius r
def point(h, k, r):
    theta = random() * 2 * pi
    x =  h + cos(theta) * r
    noise = np.random.normal(0, coxwain.getNoisePerc())
    x = x + noise
    y =  k + sin(theta) * r
    noise = np.random.normal(0, coxwain.getNoisePerc())
    y = y + noise
    return x, y










def generate_mat_dataset_given_outliers_perc(outliers_perc):


    # handle the possibility that one between the training and testing directory is empty. in such a case I won't create the data such dir
    countDir = 0
    coxwain.setCurDir(coxwain.getTrainDir())
    if coxwain.getCurDir() == '':
        countDir += 1
        coxwain.setCurDir(coxwain.getTestDir())

    while countDir < 2:
        numPoints = coxwain.getNumPointsPerSample()

        avg_num_inliers = numPoints - math.floor(float(numPoints) * outliers_perc)

        inliers_range = list(range(avg_num_inliers - 2, avg_num_inliers + 2))
        # ora ho le liste con tutti e 4 i parametri.
        # scrivo codice per samplare in modo randomico ciascun parametro
        # per ogni cerchio che creo
        circle_dt = np.dtype([('x1p', 'O'), ('x2p', 'O'), ('labels', 'O')])
        circles = []
        for _ in range(coxwain.getNumSamples()):
            x_center = uniform(-1, 1)
            y_center = uniform(-1, 1)
            radius = uniform(0.5, 1.5)
            n_inliers = inliers_range[rand.randint(0, len(inliers_range) - 1)]
            circle_mat = generate_circle(x_center, y_center, radius, n_inliers, outliers_perc=outliers_perc)
            circles.append(circle_mat)

        circle_arr = np.array(circles, dtype=circle_dt)
        dataset = np.array([circle_arr])
        # save it into a matlab file
        folder = './'+coxwain.getBaseDir()+'/' + coxwain.getCurDir() + '/circles_no_' + str(int(outliers_perc * 100)) + '.mat'
        scipy.io.savemat(folder, mdict={'dataset': dataset, 'outlierRate': outliers_perc})

        # if the test dir string is empty then I break from the while

        countDir += 1
        coxwain.setCurDir(coxwain.getTestDir())
        if coxwain.getCurDir() == '':
            break


















def startCircles():

    oRateR = coxwain.getOutliersRateRange()
    for oRate in oRateR:
        generate_mat_dataset_given_outliers_perc(oRate)
















def start():
    if coxwain.getModel() =='circle':
        startCircles()






def generate_data(num_samples: int, num_points_per_sample: int, outliers_rate_range, model: string, noise_perc: float,dest: string = 'matlab',dirs = ['first_dataset','train','.']):
    """
    :param num_samples: total number of samples to be generated for each outlier rate
    :param num_points_per_sample: total number of points within each sample
    :param outliers_rate_range: list that contains outliers rates
    :param model: a string that identifies the model to be created. the possible models are: 'circle'.
    :param noise_perc: the stddev of the gaussian noise to be added to the inliers
    :param dest: you want to read it with? 'matlab', 'numpy'
    :param dirs: list containing path to train data dir and to test data dir
    :return: a nice looking np array
    """
    coxwain.setNumSamples(num_samples)
    coxwain.setNumPointsPerSample(num_points_per_sample)
    coxwain.setOutliersRateRange(outliers_rate_range)
    coxwain.setModel(model)
    coxwain.setNoisePerc(noise_perc)
    coxwain.setDest(dest)
    coxwain.setBaseDir(dirs[0])
    coxwain.setTrainDir(dirs[1])
    coxwain.setTestDir(dirs[2])
    start()











