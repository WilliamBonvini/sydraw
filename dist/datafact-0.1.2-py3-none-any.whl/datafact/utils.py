import string
import os


def getRanges(nSamplesPerOR: int):
    """

    :param nSamplesPerOR:
    :return:
    """
    xr = 1
    yr = 1
    rr = 1
    turn = 0
    while xr*yr*rr < nSamplesPerOR:
        if turn == 0:
            xr *= 2
        elif turn == 1:
            yr *= 2
        elif turn == 2:
            rr *= 2
            turn = -1
        turn += 1

    return [xr,yr,rr]









def checkExistenceAndCreate(path: string):
    """

    :param path: takes full path of mat file, included the name of the file
    :return:
    """
    folders = path.split('/')
    folders = folders[1:-1]  # dont' care about the '.' nor the name of the file
    path = folders[0]
    if not os.exists(path):
        os.mkdir(path)
    path = path + '/' + folders[1]
    if not os.exists(path):
        os.mkdir(path)
    path = path + '/' + folders[2]
    if not os.exists(path):
        os.mkdir(path)
    path = path + '/' + folders[3]
    if not os.exists(path):
        os.mkdir(path)






