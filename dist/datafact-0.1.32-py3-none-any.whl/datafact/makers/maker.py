
from abc import ABC, abstractmethod
from random import uniform


class Maker(ABC):
    NUM_SAMPLES = None
    NUM_POINTS_PER_SAMPLE = None
    BASE_DIR = None
    TRAIN_DIR = None
    TEST_DIR = None
    CUR_DIR = None
    NUMBER_OF_MODELS = None
    OUTLIERS_PERC_RANGE = None
    NOISE_PERC_RANGE = None
    NOISE_PERC = None
    OUTLIERS_PERC = None
    INLIERS_RANGE = None
    IMG_DIR = None



    @abstractmethod
    def generate_random_sample(self):
        """
        generates a random sample of the desired type.
        a sample is defined as written in the return field of the doc

        :return: np.array with NUM_POINTS_PER_SAMPLE points,
        where each point is or an outlier or belongs to any
        of the NUM_MODELS models.
        """
        pass

    @abstractmethod
    def generate_dataset_fixed_nr_and_or(self):
        pass

    def setInliersRange(self,inliersRange):
        self._inliersRange = inliersRange

    def getInliersRange(self):
        return self._inliersRange

    def setNoisePerc(self,noisePerc):
        self._noisePerc = noisePerc

    def getNoisePerc(self):
        return self._noisePerc

    def generate_outliers(self, n_outliers):

        outliers = [(uniform(-2.5, 2.5), uniform(-2.5, 2.5)) for _ in range(n_outliers)]
        return outliers

    def start(self):

        for nPerc in Maker.NOISE_PERC_RANGE:
            for oPerc in Maker.OUTLIERS_PERC_RANGE:
                self.setNoisePerc(nPerc)
                Maker.NOISE_PERC = nPerc
                Maker.OUTLIERS_PERC = oPerc
                self.generate_dataset_fixed_nr_and_or()

