import math
from random import uniform
import numpy as np
import matplotlib.pyplot as plt
import random as rand
import scipy.io

from datafact.makers.maker import Maker
from datafact.pointgenerator import point, outliers_uniform
from datafact.utils.utils import checkExistenceAndCreate, convert_to_np_struct_and_shuffle, convert_to_mat_struct, \
    compute_num_of_inliers_for_each_model, plot_sample, save_pic_once_in_a_while


class CircleMaker(Maker):
    CIRCLE_DT = np.dtype([('x1p', 'O'), ('x2p', 'O'), ('labels', 'O')])

    def __init__(self):
        super(CircleMaker, self).__init__()

    @staticmethod
    def generate_random_model(n_inliers=None):
        """
        :param n_inliers: number of inlier points for this specific model
        :return:
        """
        x_center = uniform(-1, 1)
        y_center = uniform(-1, 1)
        radius = uniform(0.5, 1.5)
        xy = [point(y_center, x_center, radius, CircleMaker.NOISE_PERC) for _ in range(n_inliers)]
        return xy

    def generate_random_sample(self, plot=True):
        """

        :param plot:
        :return:
        """

        n_tot_inliers = rand.choice(CircleMaker.INLIERS_RANGE)
        n_inliers_for_each_model = compute_num_of_inliers_for_each_model(n_tot_inliers, CircleMaker.NUMBER_OF_MODELS)
        inliers = []

        for n_inliers in n_inliers_for_each_model:
            model_inliers = self.generate_random_model(n_inliers=n_inliers)
            inliers.append(model_inliers)

        # flatten inliers
        inliers = [item for sublist in inliers for item in sublist]

        n_outliers = CircleMaker.NUM_POINTS_PER_SAMPLE - n_tot_inliers
        outliers = self.generate_outliers(n_outliers)

        if plot:
            plot_sample(inliers, outliers)
            save_pic_once_in_a_while(CircleMaker.IMG_DIR)

        sample = convert_to_np_struct_and_shuffle(inliers, outliers)
        sample_mat = convert_to_mat_struct(sample)

        return sample_mat

    def generate_dataset_fixed_nr_and_or(self):
        """

        :return:
        """

        avg_num_inliers = math.floor(CircleMaker.NUM_POINTS_PER_SAMPLE*(1.0 - CircleMaker.OUTLIERS_PERC))
        inliers_range = list(range(avg_num_inliers - 2, avg_num_inliers + 2))
        CircleMaker.INLIERS_RANGE = inliers_range

        # handle possibility that training or testing directory are empty
        for curDir in [CircleMaker.TRAIN_DIR, CircleMaker.TEST_DIR]:
            if curDir == '':
                continue
            CircleMaker.CUR_DIR = curDir
            CircleMaker.IMG_DIR = './' + CircleMaker.BASE_DIR + '/' + CircleMaker.CUR_DIR + '/' + 'imgs' + '/' + 'circles_no_' + str(
            int(CircleMaker.OUTLIERS_PERC * 100)) + '_noise_' + str(CircleMaker.NOISE_PERC)
            samples = []
            for _ in range(CircleMaker.NUM_SAMPLES):

                sample = self.generate_random_sample()
                samples.append(sample)

            samples = np.array(samples, dtype=CircleMaker.CIRCLE_DT)
            dataset = np.array([samples])
            # save it into a matlab file
            folder = './' + CircleMaker.BASE_DIR + '/' + curDir + '/circles_no_' + str(
                int(CircleMaker.OUTLIERS_PERC * 100)) + '_noise_' + str(CircleMaker.NOISE_PERC)+ '.mat'
            scipy.io.savemat(folder, mdict={'dataset': dataset, 'outlierRate': CircleMaker.OUTLIERS_PERC})














